﻿using BoatProduction.Models.Entities;
using BoatProduction.Models.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace BoatProduction.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser, IdentityRole<int>, int>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Boat> Boats => Set<Boat>();
    public DbSet<Status> Statuses => Set<Status>();
    public DbSet<Color> Colors => Set<Color>();
    public DbSet<Model> Models => Set<Model>();
    public DbSet<StatusHistory> StatusHistories => Set<StatusHistory>();
    public DbSet<BoatAttachment> Attachments => Set<BoatAttachment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // --- Индексы для частых выборок [1] ---
        b.Entity<Boat>().HasIndex(x => x.Vin).IsUnique();
        b.Entity<Boat>().HasIndex(x => x.StatusId);
        b.Entity<Boat>().HasIndex(x => x.ModelId);
        b.Entity<Boat>().HasIndex(x => x.AssignedExecutor);
        b.Entity<Boat>().HasIndex(x => new { x.StatusId, x.ModelId }); // Комбинированный фильтр

        // --- Seed Data: Статусы [2] ---
        var statuses = new[]
        {
            new Status { Id = 1, Name = "Крой", SortOrder = 1 },
            new Status { Id = 2, Name = "Детали", SortOrder = 2 },
            new Status { Id = 3, Name = "Доукомплектовка", SortOrder = 3 },
            new Status { Id = 4, Name = "Сборка", SortOrder = 4 },
            new Status { Id = 5, Name = "Отк", SortOrder = 5 },
            new Status { Id = 6, Name = "Склад", SortOrder = 6 },
            new Status { Id = 7, Name = "на отгрузку", SortOrder = 7 },
            new Status { Id = 8, Name = "склад Б/У", SortOrder = 8 },
            new Status { Id = 9, Name = "склад дальний", SortOrder = 9 },
            new Status { Id = 10, Name = "отгружено", SortOrder = 10, IsFinal = true }
        };
        b.Entity<Status>().HasData(statuses);

        // --- Seed Data: Цвета [3] ---
        var colors = new[]
        {
            new Color { Id = 1, Name = "Сер", HexCode = "#808080" },
            new Color { Id = 2, Name = "Зел", HexCode = "#008000" },
            new Color { Id = 3, Name = "Крас", HexCode = "#FF0000" },
            new Color { Id = 4, Name = "Графит", HexCode = "#383838" },
            new Color { Id = 5, Name = "Норвик", HexCode = "#0047AB" }, // Примерный
            new Color { Id = 6, Name = "Жёлт", HexCode = "#FFFF00" },
            new Color { Id = 7, Name = "Оранж", HexCode = "#FFA500" },
            new Color { Id = 8, Name = "Лайм", HexCode = "#32CD32" },
            new Color { Id = 9, Name = "Арктик", HexCode = "#E0FFFF" },
            new Color { Id = 10, Name = "Белый", HexCode = "#FFFFFF" },
            new Color { Id = 11, Name = "Комби", HexCode = "#FF1493" } // Разноцветный
        };
        b.Entity<Color>().HasData(colors);

        // --- Seed Data: Модели [4] ---
        var models = new List<Model>
        {
            new Model { Id = 1, Name = "35" }, new Model { Id = 2, Name = "40" }, new Model { Id = 3, Name = "45" },
            new Model { Id = 4, Name = "50" }, new Model { Id = 5, Name = "55" }, new Model { Id = 6, Name = "60" },
            new Model { Id = 7, Name = "500Э" }, new Model { Id = 8, Name = "430Э" }, new Model { Id = 9, Name = "380Э" },
            new Model { Id = 10, Name = "380Р" }, new Model { Id = 11, Name = "430Р" }, new Model { Id = 12, Name = "380К" },
            new Model { Id = 13, Name = "410" }, new Model { Id = 14, Name = "420" }, new Model { Id = 15, Name = "420М" },
            new Model { Id = 16, Name = "460" }, new Model { Id = 17, Name = "460М" }, new Model { Id = 18, Name = "520" },
            new Model { Id = 19, Name = "520М" }, new Model { Id = 20, Name = "660" }, new Model { Id = 21, Name = "750" },
            // Служебные [4]
            new Model { Id = 22, Name = "НЕ ЛОДКИ", IsServiceModel = true },
            new Model { Id = 23, Name = "Буй", IsServiceModel = true },
            new Model { Id = 24, Name = "Доп", IsServiceModel = true },
            new Model { Id = 25, Name = "Ремонт", IsServiceModel = true }
        };
        b.Entity<Model>().HasData(models);

        // Настройка каскадного удаления для истории/вложений
        b.Entity<Boat>()
            .HasMany(b => b.StatusHistory)
            .WithOne(h => h.Boat)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Boat>()
            .HasMany(b => b.Attachments)
            .WithOne(a => a.Boat)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
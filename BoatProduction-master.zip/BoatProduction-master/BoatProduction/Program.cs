using Blazor.Bootstrap; // Для UI компонентов
using BoatProduction.Data;
using BoatProduction.Models.Entities;
using BoatProduction.Models.Enums;
using BoatProduction.Services.Implementations;
using BoatProduction.Services.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1. DB & Identity
builder.Services.AddDbContext<ApplicationDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<ApplicationUser, IdentityRole<int>>(opt =>
{
    opt.Password.RequireDigit = false;
    opt.Password.RequiredLength = 4;
    opt.Password.RequireNonAlphanumeric = false;
    opt.Password.RequireUppercase = false;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(opt =>
{
    opt.LoginPath = "/login";
    opt.AccessDeniedPath = "/accessdenied";
    opt.ExpireTimeSpan = TimeSpan.FromHours(8);
});

// 2. Services
builder.Services.AddScoped<IBoatService, BoatService>();
builder.Services.AddScoped<ReferenceDataService>();

// 3. Blazor Bootstrap
builder.Services.AddBlazorBootstrap();

builder.Services.AddRazorComponents().AddInteractiveServerComponents();

var app = builder.Build();

// --- Seed Roles & Admin User ---
using (var scope = app.Services.CreateScope())
{
    var rm = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<int>>>();
    var um = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

    foreach (var r in Enum.GetNames<UserRole>())
        if (!await rm.RoleExistsAsync(r)) await rm.CreateAsync(new IdentityRole<int>(r));

    // Создаем админа по умолчанию
    var adminEmail = "admin@boat.local";
    if (await um.FindByEmailAsync(adminEmail) == null)
    {
        var admin = new ApplicationUser { UserName = adminEmail, Email = adminEmail, FullName = "Администратор", Role = UserRole.Administrator };
        await um.CreateAsync(admin, "Admin123!");
        await um.AddToRoleAsync(admin, UserRole.Administrator.ToString());
    }
}

// Pipeline
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Error"); app.UseHsts(); }
app.UseHttpsRedirection(); app.UseStaticFiles(); app.UseAntiforgery();
app.UseAuthentication(); app.UseAuthorization();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.Run();
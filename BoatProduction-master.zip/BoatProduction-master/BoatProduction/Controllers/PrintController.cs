﻿// Controllers/PrintController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using BoatProduction.Services.Print;

namespace BoatProduction.Controllers;

[Authorize(Roles = "Administrator, ProductionManager")]
[ApiController]
[Route("api/print")]
public class PrintController : ControllerBase
{
    private readonly PrintService _print;
    public PrintController(PrintService print) => _print = print;

    [HttpGet("production/{id}")]
    public IActionResult ProductionCard(int id) => File(_print.GenerateProductionCard(id), "application/pdf", $"Production_{id}.pdf");

    [HttpGet("assembly/{id}")]
    public IActionResult AssemblySheet(int id) => File(_print.GenerateAssemblySheet(id), "application/pdf", $"Assembly_{id}.pdf");

    [HttpGet("shipment/{id}")]
    public IActionResult ShipmentDoc(int id) => File(_print.GenerateShipmentDocument(id), "application/pdf", $"Shipment_{id}.pdf");
}
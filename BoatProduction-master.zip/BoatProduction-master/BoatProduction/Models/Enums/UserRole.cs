﻿namespace BoatProduction.Models.Enums;

public enum UserRole
{
    Administrator = 1,      // Полный доступ [1]
    ProductionManager = 2   // Просмотр, смена статусов, назначение исполнителей, присвоение номеров [1]
}
﻿using Microsoft.AspNetCore.Identity;
using BoatProduction.Models.Enums;

namespace BoatProduction.Models.Entities;

public class ApplicationUser : IdentityUser<int>
{
    public string FullName { get; set; } = string.Empty;
    public UserRole Role { get; set; } = UserRole.ProductionManager;
    public bool IsActive { get; set; } = true;
}
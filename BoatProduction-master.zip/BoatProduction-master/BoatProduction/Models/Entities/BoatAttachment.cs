﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoatProduction.Models.Entities;

[Table("BoatAttachments")]
public class BoatAttachment
{
    [Key] public int Id { get; set; }
    [Required] public int BoatId { get; set; }
    [ForeignKey(nameof(BoatId))] public Boat Boat { get; set; } = default!;

    [Required, MaxLength(255)] public string FileName { get; set; } = default!;
    [Required, MaxLength(500)] public string FilePath { get; set; } = default!; // Путь в wwwroot/uploads
    public long FileSize { get; set; }
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
}
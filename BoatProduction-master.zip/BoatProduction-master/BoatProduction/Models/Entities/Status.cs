﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoatProduction.Models.Entities;

[Table("Statuses")]
public class Status
{
    [Key] public int Id { get; set; }

    [Required, MaxLength(50)]
    public string Name { get; set; } = default!; // Крой, Детали, Доукомплектовка, Сборка, Отк, Склад, на отгрузку, склад Б/У, склад дальний, отгружено [2]

    public int SortOrder { get; set; } // Для сортировки в канбан/таблице
    public bool IsFinal { get; set; }  // true для "отгружено"

    // Навигация
    public ICollection<Boat> Boats { get; set; } = new List<Boat>();
    public ICollection<StatusTransition> AllowedTransitions { get; set; } = new List<StatusTransition>();
}
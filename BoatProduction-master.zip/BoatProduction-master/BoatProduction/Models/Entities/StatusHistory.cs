﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoatProduction.Models.Entities;

[Table("StatusHistory")]
public class StatusHistory
{
    [Key] public int Id { get; set; }

    [Required] public int BoatId { get; set; }
    [ForeignKey(nameof(BoatId))] public Boat Boat { get; set; } = default!;

    [Required] public int FromStatusId { get; set; }
    [ForeignKey(nameof(FromStatusId))] public Status FromStatus { get; set; } = default!;

    [Required] public int ToStatusId { get; set; }
    [ForeignKey(nameof(ToStatusId))] public Status ToStatus { get; set; } = default!;

    [Required] public DateTime ChangedAt { get; set; } = DateTime.UtcNow;

    [MaxLength(100)] public string? ChangedByUser { get; set; }
    [MaxLength(500)] public string? Comment { get; set; }
}
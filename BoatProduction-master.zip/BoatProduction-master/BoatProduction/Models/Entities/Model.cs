﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoatProduction.Models.Entities;

[Table("Models")]
public class Model
{
    [Key] public int Id { get; set; }

    [Required, MaxLength(50)]
    public string Name { get; set; } = default!; // 35, 40, 45... 750, НЕ ЛОДКИ, Буй, Доп, Ремонт [4]

    public bool IsServiceModel { get; set; } // true для Буй, Доп, Ремонт, НЕ ЛОДКИ
    public ICollection<Boat> Boats { get; set; } = new List<Boat>();
}
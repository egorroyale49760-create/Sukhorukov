﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BoatProduction.Models.Enums;

namespace BoatProduction.Models.Entities;

[Table("Boats")]
public class Boat
{
    [Key] public int Id { get; set; }

    // --- Идентификация ---
    [Required, MaxLength(50)]
    [Index(IsUnique = true)] // Уникальность VIN [1]
    public string Vin { get; set; } = default!; // VIN-номер

    [MaxLength(20)]
    public string? Number { get; set; } // Присваиваемый номер (Зав. пр-вом) [1]

    // --- Ссылки на справочники ---
    [Required] public int ModelId { get; set; }
    [ForeignKey(nameof(ModelId))] public Model Model { get; set; } = default!;

    [Required] public int ColorId { get; set; }
    [ForeignKey(nameof(ColorId))] public Color Color { get; set; } = default!;

    [Required] public int StatusId { get; set; }
    [ForeignKey(nameof(StatusId))] public Status Status { get; set; } = default!;

    // --- Производственные данные ---
    [MaxLength(100)] public string? WorkOrderNumber { get; set; } // [Заказ-наряд] [1]
    [MaxLength(100)] public string? ActualCargoSize { get; set; } // [Фактический размер груза] [1]

    public DateTime? ProductionStartDate { get; set; }
    public DateTime? EstimatedCompletionDate { get; set; }
    public DateTime? ActualCompletionDate { get; set; }

    // --- Исполнители / Ответственные ---
    [MaxLength(100)] public string? AssignedExecutor { get; set; } // Назначение исполнителей [1]
    [MaxLength(100)] public string? QualityInspector { get; set; } // ОТК

    // --- Логистика / Склад ---
    [MaxLength(200)] public string? StorageLocation { get; set; } // Склад, Склад Б/У, Склад дальний [2]
    [MaxLength(100)] public string? ShipmentNumber { get; set; }
    public DateTime? ShipmentDate { get; set; }

    // --- Метаданные ---
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public string? CreatedByUserId { get; set; }

    // --- История статусов ---
    public ICollection<StatusHistory> StatusHistory { get; set; } = new List<StatusHistory>();

    // --- Вложения (пути к PNG схемам) ---
    public ICollection<BoatAttachment> Attachments { get; set; } = new List<BoatAttachment>();
}
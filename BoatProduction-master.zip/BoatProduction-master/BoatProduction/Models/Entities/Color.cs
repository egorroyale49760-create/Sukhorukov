﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoatProduction.Models.Entities;

[Table("Colors")]
public class Color
{
    [Key] public int Id { get; set; }

    [Required, MaxLength(50)]
    public string Name { get; set; } = default!; // Сер, Зел, Крас, Графит, Норвик, Жёлт, Оранж, Лайм, Арктик, Белый, Комби [3]

    public string? HexCode { get; set; } // Для UI бейджей
    public ICollection<Boat> Boats { get; set; } = new List<Boat>();
}
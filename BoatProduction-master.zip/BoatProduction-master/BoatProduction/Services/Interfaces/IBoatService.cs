﻿using BoatProduction.Models.Entities;
using BoatProduction.Models.DTOs; // Создадим ниже

namespace BoatProduction.Services.Interfaces;

public interface IBoatService
{
    Task<PagedResult<BoatListDto>> GetFilteredAsync(BoatFilterDto filter);
    Task<BoatDetailDto?> GetByIdAsync(int id);
    Task<BoatDetailDto?> GetByVinAsync(string vin);
    Task<Boat> CreateAsync(CreateBoatDto dto, string userName);
    Task<Boat> UpdateAsync(int id, UpdateBoatDto dto, string userName);
    Task<bool> ChangeStatusAsync(int boatId, int newStatusId, string userName, string? comment);
    Task<List<StatusHistoryDto>> GetHistoryAsync(int boatId);
    Task<List<Status>> GetAllowedNextStatusesAsync(int currentStatusId);
    Task ImportFromCsvAsync(Stream csvStream, string userName);
}
﻿// Services/Print/PrintService.cs
using BoatProduction.Data;
using BoatProduction.Models.DTOs;
using BoatProduction.Models.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace BoatProduction.Services.Print;

public class PrintService
{
    private readonly ApplicationDbContext _db;
    public PrintService(ApplicationDbContext db) => _db = db;

    // ---------------------------------------------------------
    // ФОРМА 1: Производственная карточка (Для производства) [1]
    // ---------------------------------------------------------
    public byte[] GenerateProductionCard(int boatId)
    {
        var boat = _db.Boats.Include(b => b.Model).Include(b => b.Color).Include(b => b.Status)
            .FirstOrDefault(b => b.Id == boatId);
        if (boat == null) throw new ArgumentException("Лодка не найдена");

        var history = _db.StatusHistories.Where(h => h.BoatId == boatId)
            .OrderBy(h => h.ChangedAt).ToList();

        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Margin(30).DefaultTextStyle(x => x.FontSize(10)).Size(PageSizes.A4);
                page.Header().Element(ComposeHeader);
                page.Content().Element(c => ComposeProductionContent(c, boat, history));
                page.Footer().AlignCenter().Text(txt => txt.Span("Страница ").CurrentPageNumber().Span(" из ").TotalPages());
            });
        }).GeneratePdf();
    }

    // ---------------------------------------------------------
    // ФОРМА 2: Сборочный лист / Чертеж (Для сборочного цеха) [1]
    // ---------------------------------------------------------
    public byte[] GenerateAssemblySheet(int boatId)
    {
        var boat = _db.Boats.Include(b => b.Model).Include(b => b.Color).Include(b => b.Attachments)
            .FirstOrDefault(b => b.Id == boatId);
        if (boat == null) throw new ArgumentException("Лодка не найдена");

        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Margin(20).Size(PageSizes.A4).DefaultTextStyle(x => x.FontSize(11));
                page.Header().Element(ComposeHeader);
                page.Content().Column(col =>
                {
                    col.Spacing(15);
                    col.Item().Element(c => ComposeAssemblyHeader(c, boat));

                    // PNG Схема [1]
                    var png = boat.Attachments.FirstOrDefault(a => a.FileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase));
                    if (png != null)
                    {
                        col.Item().AlignCenter().Image(Image.FromFile(Path.Combine("wwwroot", png.FilePath.TrimStart('/')))).MaxWidth(500);
                    }
                    else
                    {
                        col.Item().AlignCenter().Padding(50).Text("Схема сборки не прикреплена").FontColor(Colors.Grey.Medium);
                    }

                    col.Item().BorderBottom(1).BorderColor(Colors.Grey.Lighten2);
                    col.Item().Text("Подпись сборщика: _______________ / Дата: _______________").FontSize(10);
                });
                page.Footer().AlignRight().Text($"ВИН: {boat.Vin} | Модель: {boat.Model.Name} | Цвет: {boat.Color.Name}");
            });
        }).GeneratePdf();
    }

    // ---------------------------------------------------------
    // ФОРМА 3: Товарная накладная / Акцепт (Для логистов) [1]
    // ---------------------------------------------------------
    public byte[] GenerateShipmentDocument(int boatId)
    {
        var boat = _db.Boats.Include(b => b.Model).Include(b => b.Color).Include(b => b.Status)
            .FirstOrDefault(b => b.Id == boatId);
        if (boat == null) throw new ArgumentException("Лодка не найдена");

        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Margin(30).Size(PageSizes.A4).DefaultTextStyle(x => x.FontSize(10));
                page.Header().Row(row =>
                {
                    row.RelativeItem().Column(col => {
                        col.Item().Text("ТОВАРНАЯ НАКЛАДНАЯ").Bold().FontSize(16).FontColor(Colors.Blue.Darken2);
                        col.Item().Text($"№ {boat.ShipmentNumber ?? boat.Vin} от {DateTime.Now:dd.MM.yyyy}");
                    });
                    row.ConstantItem(150).AlignRight().Text($"Статус: {boat.Status.Name}").Bold();
                });

                page.Content().Column(col =>
                {
                    col.Spacing(10);
                    // Грузовик/Получатель
                    col.Item().Row(r => {
                        r.RelativeItem().Text(txt => { txt.Span("Отправитель: ").Bold(); txt.Span("Завод по производству лодок"); });
                        r.RelativeItem().Text(txt => { txt.Span("Получатель: ").Bold(); txt.Span(boat.AssignedExecutor ?? "________________"); });
                    });

                    // Таблица груза
                    col.Item().Table(table =>
                    {
                        table.ColumnsDefinition(c => { c.RelativeColumn(3); c.RelativeColumn(1); c.RelativeColumn(1); c.RelativeColumn(1); });
                        table.Header(h => {
                            h.Cell().Background(Colors.Grey.Lighten3).Padding(5).Text("Наименование").Bold();
                            h.Cell().Background(Colors.Grey.Lighten3).Padding(5).AlignCenter().Text("Модель").Bold();
                            h.Cell().Background(Colors.Grey.Lighten3).Padding(5).AlignCenter().Text("Цвет").Bold();
                            h.Cell().Background(Colors.Grey.Lighten3).Padding(5).AlignCenter().Text("VIN").Bold();
                        });
                        table.Cell().Padding(5).Text($"Лодка {boat.Model.Name}");
                        table.Cell().Padding(5).AlignCenter().Text(boat.Model.Name);
                        table.Cell().Padding(5).AlignCenter().Text(boat.Color.Name);
                        table.Cell().Padding(5).AlignCenter().Text(boat.Vin);
                    });

                    col.Item().PaddingTop(30).Row(r => {
                        r.RelativeItem().Column(c => {
                            c.Item().Text("Место погрузки:").Bold(); c.Item().Text(boat.StorageLocation ?? "Склад готовой продукции");
                            c.Item().Text("Грузовик / Водитель:").Bold(); c.Item().Text("________________________");
                        });
                        r.RelativeItem().AlignRight().Column(c => {
                            c.Item().Text("Принял: _____________________ / _______________").FontSize(10); // Подпись / Дата
                            c.Item().Text("Отпустил: _____________________ / _______________").FontSize(10);
                        });
                    });
                });
                page.Footer().AlignCenter().Text("Документ сформирован автоматически системой учета производства").FontSize(8).FontColor(Colors.Grey.Medium);
            });
        }).GeneratePdf();
    }

    // --- Helpers ---
    void ComposeHeader(IContainer c) => c.Row(r => {
        r.RelativeItem().Column(col => { col.Item().Text("ЗАВОД ПРОИЗВОДСТВА ЛОДОК").Bold().FontSize(14); col.Item().Text("Производственная документация").FontSize(9).FontColor(Colors.Grey.Medium); });
        r.ConstantItem(100).AlignRight().Image(Image.FromFile("wwwroot/logo.png")).FitWidth(); // Положите logo.png в wwwroot
    });

    void ComposeProductionContent(IContainer c, Boat b, List<StatusHistory> hist)
    {
        c.Column(col => {
            col.Spacing(10);
            // Main Info Table
            col.Item().Table(t => {
                t.ColumnsDefinition(d => { d.RelativeColumn(1); d.RelativeColumn(2); d.RelativeColumn(1); d.RelativeColumn(2); });
                AddRow(t, "VIN:", b.Vin, "Модель:", b.Model.Name);
                AddRow(t, "Номер:", b.Number ?? "-", "Цвет:", b.Color.Name);
                AddRow(t, "Заказ-наряд:", b.WorkOrderNumber ?? "-", "Размер груза:", b.ActualCargoSize ?? "-");
                AddRow(t, "Статус:", b.Status.Name, "Исполнитель:", b.AssignedExecutor ?? "-");
                AddRow(t, "Начато:", b.ProductionStartDate?.ToString("dd.MM.yyyy") ?? "-", "План завершения:", b.EstimatedCompletionDate?.ToString("dd.MM.yyyy") ?? "-");
                AddRow(t, "Факт завершения:", b.ActualCompletionDate?.ToString("dd.MM.yyyy") ?? "-", "ОТК:", b.QualityInspector ?? "-");
            });

            col.Item().PaddingTop(10).Text("История статусов").Bold().FontSize(12);
            col.Item().Table(t => {
                t.ColumnsDefinition(d => { d.RelativeColumn(1); d.RelativeColumn(1); d.RelativeColumn(2); d.RelativeColumn(2); });
                t.Header(h => { h.Cell().Background(Colors.Grey.Lighten3).Padding(3).Text("Дата").Bold(); h.Cell().Background(Colors.Grey.Lighten3).Padding(3).Text("Статус").Bold(); h.Cell().Background(Colors.Grey.Lighten3).Padding(3).Text("Ответственный").Bold(); h.Cell().Background(Colors.Grey.Lighten3).Padding(3).Text("Комментарий").Bold(); });
                foreach (var h in hist)
                {
                    t.Cell().Padding(3).Text(h.ChangedAt.ToString("dd.MM HH:mm"));
                    t.Cell().Padding(3).Text($"{h.FromStatus?.Name} → {h.ToStatus?.Name}");
                    t.Cell().Padding(3).Text(h.ChangedByUser ?? "-");
                    t.Cell().Padding(3).Text(h.Comment ?? "-");
                }
            });
        });
    }

    void AddRow(QuestPDF.Fluent.TableDescriptor t, string l1, string v1, string l2, string v2)
    {
        t.Cell().Padding(3).Text(l1).SemiBold(); t.Cell().Padding(3).Text(v1);
        t.Cell().Padding(3).Text(l2).SemiBold(); t.Cell().Padding(3).Text(v2);
    }

    void ComposeAssemblyHeader(IContainer c, Boat b) => c.Column(col => {
        col.Item().Text($"СБОРОЧНЫЙ ЛИСТ: {b.Model.Name} (VIN: {b.Vin})").Bold().FontSize(16).AlignCenter();
        col.Item().Text($"Цвет: {b.Color.Name} | Исполнитель: {b.AssignedExecutor ?? "Не назначен"}").AlignCenter();
    });
}
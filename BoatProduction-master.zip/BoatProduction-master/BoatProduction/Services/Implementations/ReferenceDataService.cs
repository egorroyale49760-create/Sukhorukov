﻿using Microsoft.EntityFrameworkCore;
using BoatProduction.Data;
using BoatProduction.Models.Entities;

namespace BoatProduction.Services.Implementations;

public class ReferenceDataService
{
    private readonly ApplicationDbContext _db;
    public ReferenceDataService(ApplicationDbContext db) => _db = db;

    // Models
    public Task<List<Model>> GetModelsAsync() => _db.Models.OrderBy(m => m.Name).ToListAsync();
    public Task<Model?> GetModelAsync(int id) => _db.Models.FindAsync(id).AsTask();
    public async Task<Model> AddModelAsync(string name, bool isService)
    {
        var m = new Model { Name = name, IsServiceModel = isService };
        _db.Models.Add(m); await _db.SaveChangesAsync(); return m;
    }
    public async Task UpdateModelAsync(Model m) { _db.Models.Update(m); await _db.SaveChangesAsync(); }
    public async Task DeleteModelAsync(int id) { var m = await _db.Models.FindAsync(id); if (m != null) { _db.Models.Remove(m); await _db.SaveChangesAsync(); } }

    // Colors (аналогично)
    public Task<List<Color>> GetColorsAsync() => _db.Colors.OrderBy(c => c.Name).ToListAsync();
    public async Task<Color> AddColorAsync(string name, string? hex) { var c = new Color { Name = name, HexCode = hex }; _db.Colors.Add(c); await _db.SaveChangesAsync(); return c; }

    // Statuses (Админ может менять порядок)
    public Task<List<Status>> GetStatusesAsync() => _db.Statuses.OrderBy(s => s.SortOrder).ToListAsync();
    public async Task ReorderStatusesAsync(Dictionary<int, int> idToSortOrder)
    {
        foreach (var kv in idToSortOrder) { var s = await _db.Statuses.FindAsync(kv.Key); if (s != null) s.SortOrder = kv.Value; }
        await _db.SaveChangesAsync();
    }
}
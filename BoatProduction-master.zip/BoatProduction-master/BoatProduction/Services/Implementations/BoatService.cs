﻿using BoatProduction.Data;
using BoatProduction.Models.DTOs;
using BoatProduction.Models.Entities;
using BoatProduction.Services.Interfaces;
using CsvHelper;
using Microsoft.EntityFrameworkCore;
using System.Formats.Asn1;
using System.Globalization;

namespace BoatProduction.Services.Implementations;

public class BoatService : IBoatService
{
    private readonly ApplicationDbContext _db;
    private readonly IWebHostEnvironment _env;

    public BoatService(ApplicationDbContext db, IWebHostEnvironment env)
    {
        _db = db; _env = env;
    }

    public async Task<PagedResult<BoatListDto>> GetFilteredAsync(BoatFilterDto filter)
    {
        var query = _db.Boats
            .Include(b => b.Model)
            .Include(b => b.Color)
            .Include(b => b.Status)
            .AsNoTracking()
            .AsQueryable();

        // Фильтры [1]
        if (!string.IsNullOrWhiteSpace(filter.SearchVin))
            query = query.Where(b => b.Vin.Contains(filter.SearchVin));
        if (filter.ModelId.HasValue) query = query.Where(b => b.ModelId == filter.ModelId.Value);
        if (filter.ColorId.HasValue) query = query.Where(b => b.ColorId == filter.ColorId.Value);
        if (filter.StatusId.HasValue) query = query.Where(b => b.StatusId == filter.StatusId.Value);
        if (!string.IsNullOrWhiteSpace(filter.Executor))
            query = query.Where(b => b.AssignedExecutor != null && b.AssignedExecutor.Contains(filter.Executor));

        // Сортировка
        query = filter.SortDesc
            ? query.OrderByDescending(e => EF.Property<object>(e, filter.SortBy))
            : query.OrderBy(e => EF.Property<object>(e, filter.SortBy));

        var total = await query.CountAsync();
        var items = await query
            .Skip((filter.Page - 1) * filter.PageSize)
            .Take(filter.PageSize)
            .Select(b => new BoatListDto
            {
                Id = b.Id,
                Vin = b.Vin,
                Number = b.Number,
                ModelName = b.Model.Name,
                ColorName = b.Color.Name,
                StatusName = b.Status.Name,
                StatusSortOrder = b.Status.SortOrder,
                AssignedExecutor = b.AssignedExecutor,
                EstimatedCompletionDate = b.EstimatedCompletionDate,
                UpdatedAt = b.UpdatedAt
            })
            .ToListAsync();

        return new PagedResult<BoatListDto> { Items = items, TotalCount = total, Page = filter.Page, PageSize = filter.PageSize };
    }

    public async Task<BoatDetailDto?> GetByIdAsync(int id)
    {
        return await _db.Boats
            .Include(b => b.Model).Include(b => b.Color).Include(b => b.Status)
            .Include(b => b.StatusHistory.OrderByDescending(h => h.ChangedAt)).ThenInclude(h => h.FromStatus).Include(h => h.ToStatus)
            .Include(b => b.Attachments)
            .Where(b => b.Id == id)
            .Select(b => new BoatDetailDto
            {
                Id = b.Id,
                Vin = b.Vin,
                Number = b.Number,
                ModelName = b.Model.Name,
                ColorName = b.Color.Name,
                StatusName = b.Status.Name,
                StatusSortOrder = b.Status.SortOrder,
                AssignedExecutor = b.AssignedExecutor,
                WorkOrderNumber = b.WorkOrderNumber,
                ActualCargoSize = b.ActualCargoSize,
                ProductionStartDate = b.ProductionStartDate,
                EstimatedCompletionDate = b.EstimatedCompletionDate,
                ActualCompletionDate = b.ActualCompletionDate,
                QualityInspector = b.QualityInspector,
                StorageLocation = b.StorageLocation,
                ShipmentNumber = b.ShipmentNumber,
                ShipmentDate = b.ShipmentDate,
                UpdatedAt = b.UpdatedAt,
                History = b.StatusHistory.Select(h => new StatusHistoryDto
                {
                    ChangedAt = h.ChangedAt,
                    FromStatus = h.FromStatus.Name,
                    ToStatus = h.ToStatus.Name,
                    ChangedByUser = h.ChangedByUser,
                    Comment = h.Comment
                }).ToList(),
                Attachments = b.Attachments.Select(a => new AttachmentDto
                {
                    Id = a.Id,
                    FileName = a.FileName,
                    Url = $"/uploads/{a.FileName}",
                    UploadedAt = a.UploadedAt
                }).ToList()
            })
            .FirstOrDefaultAsync();
    }

    public async Task<Boat> CreateAsync(CreateBoatDto dto, string userName)
    {
        var initialStatus = await _db.Statuses.OrderBy(s => s.SortOrder).FirstAsync(); // "Крой"
        var boat = new Boat
        {
            Vin = dto.Vin.Trim().ToUpper(),
            ModelId = dto.ModelId,
            ColorId = dto.ColorId,
            StatusId = initialStatus.Id,
            WorkOrderNumber = dto.WorkOrderNumber,
            ActualCargoSize = dto.ActualCargoSize,
            AssignedExecutor = dto.AssignedExecutor,
            EstimatedCompletionDate = dto.EstimatedCompletionDate,
            ProductionStartDate = DateTime.UtcNow,
            CreatedByUserId = userName
        };

        _db.Boats.Add(boat);
        await _db.SaveChangesAsync();

        // Запись в историю
        _db.StatusHistories.Add(new StatusHistory
        {
            BoatId = boat.Id,
            FromStatusId = initialStatus.Id,
            ToStatusId = initialStatus.Id,
            ChangedByUser = userName,
            Comment = "Создание записи"
        });
        await _db.SaveChangesAsync();
        return boat;
    }

    public async Task<Boat> UpdateAsync(int id, UpdateBoatDto dto, string userName)
    {
        var boat = await _db.Boats.FindAsync(id) ?? throw new KeyNotFoundException("Лодка не найдена");
        var oldStatusId = boat.StatusId;

        boat.ModelId = dto.ModelId;
        boat.ColorId = dto.ColorId;
        boat.WorkOrderNumber = dto.WorkOrderNumber;
        boat.ActualCargoSize = dto.ActualCargoSize;
        boat.AssignedExecutor = dto.AssignedExecutor;
        boat.EstimatedCompletionDate = dto.EstimatedCompletionDate;
        boat.Number = dto.Number;
        boat.QualityInspector = dto.QualityInspector;
        boat.StorageLocation = dto.StorageLocation;
        boat.ShipmentNumber = dto.ShipmentNumber;
        boat.ShipmentDate = dto.ShipmentDate;
        boat.UpdatedAt = DateTime.UtcNow;

        // Смена статуса через отдельный метод (ChangeStatusAsync), но если админ прислал в Update — логируем
        if (dto.StatusId.HasValue && dto.StatusId.Value != oldStatusId)
        {
            await LogStatusChange(boat, oldStatusId, dto.StatusId.Value, userName, "Изменение через форму редактирования");
            boat.StatusId = dto.StatusId.Value;
        }

        await _db.SaveChangesAsync();
        return boat;
    }

    public async Task<bool> ChangeStatusAsync(int boatId, int newStatusId, string userName, string? comment)
    {
        var boat = await _db.Boats.FindAsync(boatId);
        if (boat == null) return false;

        var oldStatusId = boat.StatusId;
        if (oldStatusId == newStatusId) return true;

        // TODO: Добавить проверку AllowTransition (StatusTransition таблица), если нужно строгое соблюдение цепочки [1]

        boat.StatusId = newStatusId;
        boat.UpdatedAt = DateTime.UtcNow;

        // Авто-заполнение дат
        var newStatus = await _db.Statuses.FindAsync(newStatusId);
        if (newStatus?.IsFinal == true) boat.ActualCompletionDate = DateTime.UtcNow;
        if (boat.ProductionStartDate == null && newStatus?.SortOrder > 1) boat.ProductionStartDate = DateTime.UtcNow;

        await LogStatusChange(boat, oldStatusId, newStatusId, userName, comment);
        await _db.SaveChangesAsync();
        return true;
    }

    private async Task LogStatusChange(Boat boat, int fromId, int toId, string user, string? comment)
    {
        _db.StatusHistories.Add(new StatusHistory
        {
            BoatId = boat.Id,
            FromStatusId = fromId,
            ToStatusId = toId,
            ChangedByUser = user,
            Comment = comment ?? "Смена статуса"
        });
    }

    public async Task<List<StatusHistoryDto>> GetHistoryAsync(int boatId)
    {
        return await _db.StatusHistories
            .Include(h => h.FromStatus).Include(h => h.ToStatus)
            .Where(h => h.BoatId == boatId)
            .OrderByDescending(h => h.ChangedAt)
            .Select(h => new StatusHistoryDto
            {
                ChangedAt = h.ChangedAt,
                FromStatus = h.FromStatus.Name,
                ToStatus = h.ToStatus.Name,
                ChangedByUser = h.ChangedByUser,
                Comment = h.Comment
            })
            .ToListAsync();
    }

    public async Task<List<Status>> GetAllowedNextStatusesAsync(int currentStatusId)
    {
        // Простая логика: можно перейти к любому следующему по SortOrder или к финальному
        // Для строгой цепочки нужна таблица StatusTransition (исключено из MVP или добавить просто)
        return await _db.Statuses
            .Where(s => s.SortOrder >= _db.Statuses.Where(x => x.Id == currentStatusId).Select(x => x.SortOrder).FirstOrDefault())
            .OrderBy(s => s.SortOrder)
            .ToListAsync();
    }

    // --- Импорт из Google Таблиц (CSV) [1] ---
    public async Task ImportFromCsvAsync(Stream csvStream, string userName)
    {
        using var reader = new StreamReader(csvStream);
        using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

        // Настройка маппинга под ваши колонки Google Sheets
        // Пример: Vin, ModelName, ColorName, StatusName, WorkOrder, CargoSize, Executor, ...
        var records = csv.GetRecords<dynamic>(); // Или конкретный класс CsvBoatRow

        foreach (var row in records)
        {
            // TODO: Реализовать парсинг строки, поиск/создание справочников по имени, проверку дублей по VIN
            // Это разовый скрипт, логика зависит от точной структуры вашей таблицы.
            // Пример поиска модели:
            // var model = await _db.Models.FirstOrDefaultAsync(m => m.Name == row.ModelName) ?? new Model { Name = row.ModelName };
        }
        await _db.SaveChangesAsync();
    }
}